#!/bin/bash
for i in {1..100000} ; do
bitshares-pricefeed  --node=wss://api-nbs-northchina.cnvote.vip:80 --configfile /root/nbs_pricefeed/baip2.yaml update --active-key=填写见证人的私钥
sleep 600
done

